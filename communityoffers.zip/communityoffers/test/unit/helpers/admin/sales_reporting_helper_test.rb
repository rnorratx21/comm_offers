require 'test_helper'

class Admin::SalesReportingHelperTest < ActionView::TestCase
end
