require 'test_helper'

class Admin::RefundsHelperTest < ActionView::TestCase
end
