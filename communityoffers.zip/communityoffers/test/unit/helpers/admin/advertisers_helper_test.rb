require 'test_helper'

class Admin::AdvertisersHelperTest < ActionView::TestCase
end
