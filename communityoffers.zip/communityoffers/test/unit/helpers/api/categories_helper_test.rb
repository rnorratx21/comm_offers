require 'test_helper'

class Api::CategoriesHelperTest < ActionView::TestCase
end
