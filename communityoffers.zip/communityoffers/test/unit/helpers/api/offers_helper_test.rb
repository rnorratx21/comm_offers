require 'test_helper'

class Api::OffersHelperTest < ActionView::TestCase
end
