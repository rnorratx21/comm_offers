require 'test_helper'

class SalesAreasHelperTest < ActionView::TestCase
end
