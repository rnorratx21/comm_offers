require File.dirname(__FILE__) + '/../spec_helper'

describe Address do
  
  # before do
  #   @address = Address.create!(
  #     :city => "Houston", 
  #     :zip_code => "77095", 
  #     :street => "1000 FM 529", 
  #     :state => "TX",
  #     :phone_number => "555-555-5555"
  #   )
    
    # Geokit::Geocoders::MultiGeocoder.stub_method(:geocode => mock_model(Object, 
    #   :lat => 29, 
    #   :lng => -95,
    #   :street_address => "1000 FM 529",
    #   :city => "Houston",
    #   :state => "TX",
    #   :zip => "77095"
    # ))
  # end
  
  # it "should update lat" do
  #   @address.lat.should == 29.879481
  # end
  # it "should update lng" do
  #   @address.lng.should == -95.654271
  # end
  
  # describe "update" do
  #   before do
  #     @address.street = "15420 FM 529"
  #     @address.save!
  #   end
  #   
  #   it "should update lat" do
  #     @address.lat.should == 29.879265
  #   end
  #   it "should update lng" do
  #     @address.lng.should == -95.6409102
  #   end
  # end
  
  
end