Invoicing::CurrencyValue::CURRENCIES['HKD'] = {:symbol => '$', :digits => 2}
