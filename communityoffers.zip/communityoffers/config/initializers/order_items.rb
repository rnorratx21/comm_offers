OrderItems::SetupFee.default_price = 125
OrderItems::PlatinumPlan.default_price = 199
OrderItems::GoldPlan.default_price = 59
OrderItems::ZipCodeBlock.default_price = 59
OrderItems::ZipCodeBlock.zip_codes_per_block = 10
