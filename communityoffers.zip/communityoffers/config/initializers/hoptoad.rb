HoptoadNotifier.configure do |config|
  config.api_key = 'cc2bafb0cdff0b92b7ef8cf0c986376a'
end
