Time::DATE_FORMATS[:expires] = "%A, %B %d, %Y"
Time::DATE_FORMATS[:short] = "%b %d, %Y"