# Load the invoicing gem
require 'invoicing'