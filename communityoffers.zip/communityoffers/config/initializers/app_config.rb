require "#{RAILS_ROOT}/lib/ActiveRecordExtensions/active_record_extensions.rb"
require "#{RAILS_ROOT}/lib/ActiveRecordExtensions/type.rb"
