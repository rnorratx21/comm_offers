$__validate = true
$__authenticate = true

$brand_name = "CommunityOffers"
$twitter_url = "http://twitter.com/CommunityOffers"
$facebook_url = "http://www.facebook.com/pages/CommunityOffers/176643562398?sk=app_129982580378550"

$exclusive_offers_per_zip_code = 16
$sales_email_address = "sales@communityoffers.com"
$image_upload_size_limit = "100k"

$system_start_date = Date.parse("February 4, 2010")