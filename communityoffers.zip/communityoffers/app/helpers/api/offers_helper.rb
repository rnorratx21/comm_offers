module Api::OffersHelper
end
