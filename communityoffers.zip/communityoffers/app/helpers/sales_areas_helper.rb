module SalesAreasHelper
end
