module Admin::WifiHelper
end
