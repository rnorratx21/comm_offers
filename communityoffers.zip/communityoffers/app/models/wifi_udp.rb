class WifiUdp < ActiveRecord::Base
  belongs_to :contract
end
