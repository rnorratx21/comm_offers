class OffersNotifier < ActionMailer::Base
  
  # def signup_notification(offer)
  #   @offer = offer
  #   
  #   @recipients     = ["misbell@communityoffers.com"]
  #   @from           = "support@communityoffers.com"
  #   @bcc            = ["nick@communityoffers.com"]
  #   @sent_on        = Time.now
  #   @subject        = "CO - SIGNUP - New Offer Waiting: #{@offer.id} - #{@offer.advertiser.name}"
  # end
end